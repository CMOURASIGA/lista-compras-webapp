
import {
  getUserSpreadsheetId,
  findSpreadsheetByName,
  createUserSpreadsheet
} from '../services/googleSheetsService';

/**
 * Garante que a planilha do usuário esteja disponível.
 * - Primeiro tenta pegar do localStorage.
 * - Depois tenta encontrar no Google Drive.
 * - Por fim, cria uma nova se necessário.
 * @param {string} userEmail - E-mail do usuário logado
 * @returns {Promise<string>} spreadsheetId
 */
export async function ensureSpreadsheetExists(userEmail) {
  let spreadsheetId = getUserSpreadsheetId(userEmail);

  if (spreadsheetId) {
    console.log('✅ Planilha encontrada no localStorage:', spreadsheetId);
    return spreadsheetId;
  }

  const spreadsheetName = `Lista de Compras - ${userEmail}`;
  spreadsheetId = await findSpreadsheetByName(spreadsheetName);

  if (spreadsheetId) {
    console.log('✅ Planilha encontrada no Google Drive:', spreadsheetId);
    localStorage.setItem(`spreadsheetId_${userEmail}`, spreadsheetId);
    return spreadsheetId;
  }

  console.log('📄 Planilha não encontrada. Criando nova...');
  spreadsheetId = await createUserSpreadsheet(userEmail);
  return spreadsheetId;
}
